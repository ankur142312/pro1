<?php
  session_start();
  if(isset($_SESSION['uname']))
  {
        include_once("includes/config.php");
        $selectsetting = "select * from aboutus";
        $settingResult = mysqli_query($con,$selectsetting) or exit("Setting Select Fail".mysqli_error($con));
        $settingCount = mysqli_num_rows($settingResult);
        
        
        extract($_POST);
        $P1=mysqli_real_escape_string($con,$P1);
        $P2=mysqli_real_escape_string($con,$P2);
        $P3=mysqli_real_escape_string($con,$P3);
        $description=mysqli_real_escape_string($con,$description);

        if($_FILES['image1']['error']==0 && $_FILES['image2']['error']==0)
        {
            $filename1=time()."_".$_FILES['image1']['name'];
            $filename2=time()."_".$_FILES['image2']['name'];
            $path1="../images/aboutus/".$filename1;
            $path2="../images/aboutus/".$filename2;
            if(move_uploaded_file($_FILES['image1']['tmp_name'],$path1) && move_uploaded_file($_FILES['image2']['tmp_name'],$path2)){
            
                if($settingCount>0)
                {
                    $qry = "update aboutus set P1='".$P1."',P2='".$P2."',P3='".$P3."',description='".$description."',image1='".$filename1."',image2='".$filename2."' where id=1";
                }else{
                    $qry = "insert into aboutus (P1,P2,P3,description,image1,image2) values('".$P1."','".$P2."','".$P3."','".$description."','".$filename1."','".$filename1."') ";
                }
                
                mysqli_query($con,$qry) or exit("Site Information Insert Fail".mysqli_error($con));
                $_SESSION['error'] = "Site Information sucessfully";
                header("location:About_Us.php");
            }else{
                $_SESSION['error'] = "file upload failed";
                header("location:About_Us.php");
            }
        
        }
        else
        {
            if($settingCount>0)
                {
                    $qry = "update aboutus set P1='".$P1."',P2='".$P2."',P3='".$P3."',description='".$description."' where id=1";
                }else{
                    $qry = "insert into aboutus (P1,P2,P3,description) values('".$P1."','".$P2."','".$P3."','".$description."') ";
                }
                
                mysqli_query($con,$qry) or exit("Site Information Insert Fail".mysqli_error($con));
                $_SESSION['error'] = "Site Information Added sucessfully";
                header("location:About_Us.php");
        }
        
  }else{
     $_SESSION['error'] = "you are not authorize to access this page without login";
    header("location:index.php");
  }
?>