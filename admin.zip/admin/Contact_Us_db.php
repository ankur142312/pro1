<?php
  session_start();
  if(isset($_SESSION['uname']))
  {
        include_once("includes/config.php");
        $selectsetting = "select * from contactus";
        $settingResult = mysqli_query($con,$selectsetting) or exit("Setting Select Fail".mysqli_error($con));
        $settingCount = mysqli_num_rows($settingResult);
        
        
        extract($_POST);
        $description=mysqli_real_escape_string($con,$description);

                if($settingCount>0)
                {
                    $qry = "update contactus set description='".$description."',cityname1='".$cityname1."',cityadd1='".$cityadd1."',phoneno1='".$phoneno1."',cityname2='".$cityname2."',cityadd2='".$cityadd2."',phoneno2='".$phoneno2."' where id=1";
                }else{
                    $qry = "insert into contactus (description,cityname1,cityadd1,phoneno1,cityname2,cityadd2,phoneno2) values('".$description."','".$cityname1."','".$cityadd1."','".$phoneno1."','".$cityname2."','".$cityadd2."','".$phoneno2."') ";
                }
                
                mysqli_query($con,$qry) or exit("Site Information Insert Fail".mysqli_error($con));
                $_SESSION['error'] = "Site Information sucessfully";
                header("location:Contact_Us.php");
    }
    else
    {
            $_SESSION['error'] = "you are not authorize to access this page without login";
            header("location:index.php");
    }
?>