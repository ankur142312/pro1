<?php
  session_start();
  if(isset($_SESSION['uname']))
  {
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>AdminLTE 3 | Dashboard</title>

  <!-- add your style here -->
    <?php 
        include_once('includes/style.php');
    ?>

</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

  <!-- Preloader -->
  <div class="preloader flex-column justify-content-center align-items-center">
    <img class="animation__shake" src="dist/img/AdminLTELogo.png" alt="AdminLTELogo" height="60" width="60">
  </div>

  <!-- Navbar -->
    <!-- add your navbar here -->
    <?php 
        include_once('includes/header.php');
    ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
    <!-- add your sidebar here  -->
    <?php 
        include_once('includes/sidebar.php');
    ?>
  <!-- Content Wrapper. Contains page content -->

  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Site Settings</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="home.php">Home</a></li>
              <li class="breadcrumb-item active">Site Information</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
            <div class="col-md-12"> 
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Contact Us</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->

              <?php
                        include_once("includes/config.php");
                        $qry = "select * from contactus";
                        $result=mysqli_query($con,$qry) or exit("Information Select Fail".mysqli_error($con));
                        $row=mysqli_fetch_array($result);
                        
                    ?>  

              <form action="Contact_Us_db.php" method="post" enctype="multipart/form-data">
                <div class="card-body">
                  <div class="form-group">
                    <label for="exampleInputPassword1">Small Description</label>
                    <textarea name="description" class="form-control" id="description" placeholder="Enter Address"><?php echo isset($row["description"])?$row["description"]:""; ?></textarea>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">City Name</label>
                    <input type="text" class="form-control" id="cityname1" name="cityname1" placeholder="Enter Site Name" value="<?php echo isset($row["cityname1"])?$row["cityname1"]:""; ?>">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Address</label>
                    <input type="text" class="form-control" id="cityadd1" name="cityadd1" placeholder="Enter Site Name" value="<?php echo isset($row["cityadd1"])?$row["cityadd1"]:""; ?>">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Phone Number</label>
                    <input type="text" class="form-control" id="phoneno1" name="phoneno1" placeholder="Enter Mobile Number" value="<?php echo isset($row["phoneno1"])?$row["phoneno1"]:""; ?>">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">City Name</label>
                    <input type="text" class="form-control" id="cityname2" name="cityname2" placeholder="Enter Site Name" value="<?php echo isset($row["cityname2"])?$row["cityname2"]:""; ?>">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Address</label>
                    <input type="text" class="form-control" id="cityadd2" name="cityadd2" placeholder="Enter Site Name" value="<?php echo isset($row["cityadd2"])?$row["cityadd2"]:""; ?>">
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Phone Number</label>
                    <input type="text" class="form-control" id="phoneno2" name="phoneno2" placeholder="Enter Mobile Number" value="<?php echo isset($row["phoneno2"])?$row["phoneno2"]:""; ?>">
                  </div>
            
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">ADD</button>
                </div>
              </form>
            </div>
            </div>
        </div>
        <!-- /.row -->
        
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
    <!-- add footer here  -->
    <?php 
        include_once('includes/footer.php');
    ?>
  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<!-- add script here  -->
<?php 
    include_once('includes/script.php');
?>
</body>
</html>
<?php
  }else{
     $_SESSION['error'] = "you are not authorize to access this page without login";
    header("location:index.php");
  }
?>
