<?php
    $hostname="localhost";
    $username="root";
    $pass="";
    $database="project";
    $con=mysqli_connect($hostname,$username,$pass,$database) or exit("connection fail");
?>