<?php
  session_start();
  if(isset($_SESSION['uname']))
  {
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>AdminLTE 3 | Dashboard</title>

  <!-- add your style here -->
    <?php 
        include_once('includes/style.php');
    ?>

</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

  <!-- Preloader -->
  <div class="preloader flex-column justify-content-center align-items-center">
    <img class="animation__shake" src="dist/img/AdminLTELogo.png" alt="AdminLTELogo" height="60" width="60">
  </div>

  <!-- Navbar -->
    <!-- add your navbar here -->
    <?php 
        include_once('includes/header.php');
    ?>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
    <!-- add your sidebar here  -->
    <?php 
        include_once('includes/sidebar.php');
    ?>
  <!-- Content Wrapper. Contains page content -->

  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Site Settings</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="home.php">Home</a></li>
              <li class="breadcrumb-item active">Site Information</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
            <div class="col-md-12"> 
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Site Information</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->

              <?php
                        include_once("includes/config.php");
                        $qry = "select * from aboutus";
                        $result=mysqli_query($con,$qry) or exit("Information Select Fail".mysqli_error($con));
                        $row=mysqli_fetch_array($result);
                        
                    ?>  


              <form action="About_Us_db.php" method="post" enctype="multipart/form-data">
                <div class="card-body">
                    <div class="form-group">
                      <label for="exampleInputPassword1">Who We Are ?</label>
                      <textarea name="P1" class="form-control" id="P1" placeholder="Enter Address"><?php echo isset($row["P1"])?$row["P1"]:""; ?></textarea>
                    </div>
                    <div class="form-group">
                      <label for="exampleInputPassword1">Who We Do ?</label>
                      <textarea name="P2" class="form-control" id="P2" placeholder="Enter Address"><?php echo isset($row["P2"])?$row["P2"]:""; ?></textarea>
                    </div>
                    <div class="form-group">
                      <label for="exampleInputPassword1">Why Choose Us</label>
                      <textarea name="P3" class="form-control" id="P3" placeholder="Enter Address"><?php echo isset($row["P3"])?$row["P3"]:""; ?></textarea>
                    </div>
                    <div class="form-group">
                      <label for="exampleInputPassword1">Description</label>
                      <textarea name="description" class="form-control" id="description" placeholder="Enter Address"><?php echo isset($row["description"])?$row["description"]:""; ?></textarea>
                    </div>

                    <div class="form-group">
                      <label for="exampleInputFile">Select Main Image</label>
                      <div class="input-group">
                        <div class="custom-file">
                          <input type="file" class="custom-file-input" id="exampleInputFile" name="image1">
                          <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                        </div>
                      </div>
                    </div>
                    <?php
                          if(isset($row["image1"]))
                          {
                    ?>
                    <div class="form-group">
                      <label for="exampleInputPassword1">Old Image</label>
                      <div style="margin-left: 80px;">
                      <input type="hidden" name="oldimage" value="<?php echo $row['image1'] ?>">
                          <img src="../images/aboutus/<?php echo $row['image1'] ?>" alt="" width="200px">
                      </div>
                    </div>
                    <?php
                          }
                    ?>
                    <div class="form-group">
                      <label for="exampleInputFile">Select Side Image</label>
                      <div class="input-group">
                        <div class="custom-file">
                          <input type="file" class="custom-file-input" id="exampleInputFile" name="image2">
                          <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                        </div>
                      </div>
                    </div>


                    <?php
                          if(isset($row["image2"]))
                          {
                    ?>
                    <div class="form-group">
                      <label for="exampleInputPassword1">Old Image</label>
                      <div style="margin-left: 80px;">
                      <input type="hidden" name="oldimage" value="<?php echo $row['image2'] ?>">
                          <img src="../images/aboutus/<?php echo $row['image2'] ?>" alt="" width="200px">
                      </div>
                    </div>
                    <?php
                          }
                    ?>

                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">ADD</button>
                </div>
              </form>
            </div>
            </div>
        </div>
        <!-- /.row -->
        
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
    <!-- add footer here  -->
    <?php 
        include_once('includes/footer.php');
    ?>
  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<!-- add script here  -->
<?php 
    include_once('includes/script.php');
?>
</body>
</html>
<?php
  }else{
     $_SESSION['error'] = "you are not authorize to access this page without login";
    header("location:index.php");
  }
?>
